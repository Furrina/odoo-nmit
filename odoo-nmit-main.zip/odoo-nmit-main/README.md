# odoo-nmit
web-app for nmit-odoo hackathon round 1
