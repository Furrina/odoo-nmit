import { prisma } from "./db";
import type { User, Product, Category, Cart, CartItem, Order, OrderItem } from "@prisma/client";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | null>;
  getUserByEmail(email: string): Promise<User | null>;
  upsertUser(user: Partial<User>): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  
  // Product operations
  getProducts(filters?: { categoryId?: number; search?: string; limit?: number; offset?: number }): Promise<Product[]>;
  getProduct(id: number): Promise<Product | null>;
  createProduct(product: Omit<Product, 'id' | 'createdAt'>): Promise<Product>;
  updateProduct(id: number, product: Partial<Omit<Product, 'id' | 'createdAt'>>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;
  getUserProducts(userId: string): Promise<Product[]>;
  
  // Cart operations
  getCart(userId: string): Promise<Cart | null>;
  getCartWithItems(userId: string): Promise<{ cart: Cart; items: (CartItem & { product: Product })[] } | null>;
  addToCart(userId: string, productId: number, qty: number): Promise<CartItem>;
  updateCartItem(userId: string, productId: number, qty: number): Promise<CartItem>;
  removeFromCart(userId: string, productId: number): Promise<void>;
  clearCart(userId: string): Promise<void>;
  
  // Order operations
  getUserOrders(userId: string): Promise<(Order & { items: (OrderItem & { product: Product })[] })[]>;
  createOrder(order: Omit<Order, 'id' | 'createdAt'> & { items: Omit<OrderItem, 'orderId'>[] }): Promise<Order>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | null> {
    return await prisma.user.findUnique({ where: { id } });
  }

  async getUserByEmail(email: string): Promise<User | null> {
    return await prisma.user.findUnique({ where: { email } });
  }

  async upsertUser(userData: Partial<User>): Promise<User> {
    if (userData.id) {
      return await prisma.user.upsert({
        where: { id: userData.id },
        update: { ...userData, updatedAt: new Date() },
        create: userData as User,
      });
    } else {
      return await prisma.user.create({ data: userData as User });
    }
  }
  
  // Category operations
  async getCategories(): Promise<Category[]> {
    return await prisma.category.findMany();
  }
  
  // Product operations
  async getProducts(filters?: { categoryId?: number; search?: string; limit?: number; offset?: number; sortBy?: string; includeSold?: boolean }): Promise<(Product & { category: { name: string } | null })[]> {
    const where: any = { status: "active" };
    
    // If includeSold is false or not specified, only show active products
    if (!filters?.includeSold) {
      where.status = "active";
    }
    
    if (filters?.categoryId) {
      where.categoryId = filters.categoryId;
    }
    
    if (filters?.search) {
      where.title = { contains: filters.search, mode: 'insensitive' };
    }

    let orderBy: any = { createdAt: 'desc' };
    if (filters?.sortBy) {
      switch (filters.sortBy) {
        case 'price-low':
          orderBy = { priceCents: 'asc' };
          break;
        case 'price-high':
          orderBy = { priceCents: 'desc' };
          break;
        case 'newest':
          orderBy = { createdAt: 'desc' };
          break;
        case 'popular':
          // For now, just use newest as we don't have view counts
          orderBy = { createdAt: 'desc' };
          break;
      }
    }
    
    return await prisma.product.findMany({
      where,
      orderBy,
      take: filters?.limit || 20,
      skip: filters?.offset || 0,
      include: {
        category: {
          select: { name: true }
        }
      },
    });
  }
  
  async getProduct(id: number): Promise<Product | null> {
    return await prisma.product.findUnique({ where: { id } });
  }
  
  async createProduct(product: Omit<Product, 'id' | 'createdAt'>): Promise<Product> {
    return await prisma.product.create({ data: product });
  }
  
  async updateProduct(id: number, product: Partial<Omit<Product, 'id' | 'createdAt'>>): Promise<Product> {
    return await prisma.product.update({ where: { id }, data: product });
  }
  
  async deleteProduct(id: number): Promise<void> {
    await prisma.product.delete({ where: { id } });
  }
  
  async getUserProducts(userId: string): Promise<Product[]> {
    return await prisma.product.findMany({
      where: { ownerId: userId },
      orderBy: { createdAt: 'desc' },
    });
  }
  
  // Cart operations
  async getCart(userId: string): Promise<Cart | null> {
    return await prisma.cart.findUnique({ where: { userId } });
  }
  
  async getCartWithItems(userId: string): Promise<{ cart: Cart; items: (CartItem & { product: Product })[] } | null> {
    let cart = await this.getCart(userId);
    
    if (!cart) {
      cart = await prisma.cart.create({ data: { userId } });
    }
    
    const items = await prisma.cartItem.findMany({
      where: { cartId: cart.id },
    });
    
    // Fetch products separately
    const itemsWithProducts = await Promise.all(
      items.map(async (item) => {
        const product = await prisma.product.findUnique({
          where: { id: item.productId },
        });
        return { ...item, product: product! };
      })
    );
    
    return { cart, items: itemsWithProducts };
  }
  
  async addToCart(userId: string, productId: number, qty: number): Promise<CartItem> {
    let cart = await this.getCart(userId);
    
    if (!cart) {
      cart = await prisma.cart.create({ data: { userId } });
    }
    
    // Try to update existing item first
    const existingItem = await prisma.cartItem.findUnique({
      where: { cartId_productId: { cartId: cart.id, productId } },
    });
    
    if (existingItem) {
      return await prisma.cartItem.update({
        where: { cartId_productId: { cartId: cart.id, productId } },
        data: { qty: existingItem.qty + qty },
      });
    } else {
      return await prisma.cartItem.create({
        data: { cartId: cart.id, productId, qty },
      });
    }
  }
  
  async updateCartItem(userId: string, productId: number, qty: number): Promise<CartItem> {
    const cart = await this.getCart(userId);
    if (!cart) throw new Error("Cart not found");
    
    return await prisma.cartItem.update({
      where: { cartId_productId: { cartId: cart.id, productId } },
      data: { qty },
    });
  }
  
  async removeFromCart(userId: string, productId: number): Promise<void> {
    const cart = await this.getCart(userId);
    if (!cart) return;
    
    await prisma.cartItem.delete({
      where: { cartId_productId: { cartId: cart.id, productId } },
    });
  }
  
  async clearCart(userId: string): Promise<void> {
    const cart = await this.getCart(userId);
    if (!cart) return;
    
    await prisma.cartItem.deleteMany({ where: { cartId: cart.id } });
  }
  
  // Order operations
  async getUserOrders(userId: string): Promise<(Order & { items: (OrderItem & { product: Product })[] })[]> {
    const orders = await prisma.order.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });
    
    // Fetch order items and products separately
    const ordersWithItems = await Promise.all(
      orders.map(async (order) => {
        const orderItems = await prisma.orderItem.findMany({
          where: { orderId: order.id },
        });
        
        const itemsWithProducts = await Promise.all(
          orderItems.map(async (item) => {
            const product = await prisma.product.findUnique({
              where: { id: item.productId },
            });
            return { ...item, product: product! };
          })
        );
        
        return { ...order, items: itemsWithProducts };
      })
    );
    
    return ordersWithItems;
  }
  
  async createOrder(orderData: Omit<Order, 'id' | 'createdAt'> & { items: Omit<OrderItem, 'orderId'>[] }): Promise<Order> {
    const { items, ...order } = orderData;
    
    return await prisma.order.create({
      data: {
        ...order,
        items: {
          create: items,
        },
      },
    });
  }
}

export const storage = new DatabaseStorage();